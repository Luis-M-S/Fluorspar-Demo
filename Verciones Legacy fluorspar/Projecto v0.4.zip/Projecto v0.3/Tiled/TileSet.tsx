<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="TileSet" tilewidth="16" tileheight="16" tilecount="256" columns="16">
 <image source="../Assets/TileSet.png" width="256" height="256"/>
 <tile id="96">
  <objectgroup draworder="index" id="2">
   <object id="3" template="Coliciones/Esquina.tx" x="16.0313" y="0.0625"/>
  </objectgroup>
 </tile>
 <tile id="97">
  <objectgroup draworder="index" id="2">
   <object id="2" template="Coliciones/Pared.tx" x="0.0625" y="0.0625"/>
  </objectgroup>
 </tile>
 <tile id="98">
  <objectgroup draworder="index" id="6">
   <object id="10" template="Coliciones/Pared.tx" x="0.0625" y="0"/>
  </objectgroup>
 </tile>
 <tile id="99">
  <objectgroup draworder="index" id="2">
   <object id="2" template="Coliciones/Pared.tx" x="0.0625" y="0.0625"/>
  </objectgroup>
 </tile>
 <tile id="100">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Esquina.tx" x="16.0028" y="16.014" rotation="89.8754"/>
  </objectgroup>
 </tile>
 <tile id="112">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Pared.tx" x="7.9381" y="0.0456971" rotation="89.4366"/>
  </objectgroup>
 </tile>
 <tile id="116">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Pared.tx" x="15.9696" y="0.138638" rotation="90.084"/>
  </objectgroup>
 </tile>
 <tile id="128">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Pared.tx" x="7.79716" y="0.0379612" rotation="89.3221"/>
  </objectgroup>
 </tile>
 <tile id="132">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Pared.tx" gid="0" x="16.0554" y="0.0419344" rotation="89.3809"/>
  </objectgroup>
 </tile>
 <tile id="133">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Pared.tx" x="0.0888889" y="0.0888889"/>
  </objectgroup>
 </tile>
 <tile id="144">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Pared.tx" x="7.87337" y="0.23211" rotation="89.4205"/>
  </objectgroup>
 </tile>
 <tile id="148">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Pared.tx" x="16.0074" y="0.14229" rotation="89.9358"/>
  </objectgroup>
 </tile>
 <tile id="149">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Pared.tx" x="0.0888889" y="8.04444"/>
  </objectgroup>
 </tile>
 <tile id="160">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Esquina.tx" gid="0" x="15.875" y="16" rotation="0">
    <polygon points="-0.0390625,0.0585938 -0.0390625,-7.9375 -6.04297,-9.94141 -8.04297,-15.9258 -16.0352,-15.9336 -16.043,0.0585938"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="161">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Pared.tx" x="0.0625" y="7.9375"/>
  </objectgroup>
 </tile>
 <tile id="164">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Esquina.tx" gid="0" x="0.0429375" y="16" rotation="0">
    <polygon points="0.0390625,0.0585938 0.0390625,-7.9375 6.04297,-9.94141 8.04297,-15.9258 16.0352,-15.9336 16.043,0.0585938"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="165">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Esquina.tx" x="16" y="0.0625"/>
  </objectgroup>
 </tile>
 <tile id="166">
  <objectgroup draworder="index" id="2">
   <object id="2" template="Coliciones/Pared.tx" x="0.0666667" y="0.0222222"/>
  </objectgroup>
 </tile>
 <tile id="167">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Esquina.tx" gid="0" x="-0.0195625" y="0" rotation="0">
    <polygon points="0.0390625,-0.0585938 0.0390625,7.9375 6.04297,9.94141 8.04297,15.9258 16.0352,15.9336 16.043,-0.0585938"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="176">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="-0.0869565">
    <polygon points="0,0 0.0869565,16.087 7.91304,16.0435 10.087,10.0435 16,8.04348 16,0.130435"/>
   </object>
   <object id="2" template="Coliciones/Esquina.tx" x="0" y="0">
    <polygon points="0,0 11.6087,0 16,0 16,16 0,16"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="177">
  <objectgroup draworder="index" id="2">
   <object id="2" template="Coliciones/Pared.tx" x="-0.125" y="0.125"/>
  </objectgroup>
 </tile>
 <tile id="178">
  <objectgroup draworder="index" id="2">
   <object id="3" template="Coliciones/Pared.tx" x="0.0625" y="0"/>
  </objectgroup>
 </tile>
 <tile id="179">
  <objectgroup draworder="index" id="2">
   <object id="3" template="Coliciones/Pared.tx" x="0.0625" y="0.125"/>
  </objectgroup>
 </tile>
 <tile id="180">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Esquina.tx" gid="0" x="-0.144562" y="0.0625" rotation="0">
    <polygon points="0.0390625,-0.0585938 0.0390625,7.9375 6.04297,9.94141 8.04297,15.9258 16.0352,15.9336 16.043,-0.0585938"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="182">
  <objectgroup draworder="index" id="3">
   <object id="3" x="10" y="6.33333" width="0.0222222" height="0.0222222"/>
   <object id="5" template="Coliciones/Bloque.tx" x="-0.0625" y="0.0625"/>
  </objectgroup>
 </tile>
 <tile id="192">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Pared.tx" x="7.87632" y="0.076757" rotation="89.8917"/>
  </objectgroup>
 </tile>
 <tile id="195">
  <objectgroup draworder="index" id="2">
   <object id="1" x="-0.0434783" y="-0.0434783" width="15.9565" height="16"/>
  </objectgroup>
 </tile>
 <tile id="196">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Pared.tx" x="15.8682" y="-0.0204208" rotation="89.3831"/>
  </objectgroup>
 </tile>
 <tile id="197">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Esquina.tx" gid="0" x="16" y="16.125" rotation="0">
    <polygon points="-0.0390625,0.0585938 -0.0390625,-7.9375 -6.04297,-9.94141 -8.04297,-15.9258 -16.0352,-15.9336 -16.043,0.0585938"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="198">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Pared.tx" x="0.125" y="8.1875"/>
  </objectgroup>
 </tile>
 <tile id="199">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Esquina.tx" gid="0" x="-0.144562" y="16.125" rotation="0">
    <polygon points="0.0390625,0.0585938 0.0390625,-7.9375 6.04297,-9.94141 8.04297,-15.9258 16.0352,-15.9336 16.043,0.0585938"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="202">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/sin nombre.tx" x="0.0869565" y="0.130435"/>
   <object id="2" template="Coliciones/sin nombre.tx" x="0.0869565" y="0.130435"/>
   <object id="3" template="Coliciones/sin nombre.tx" x="0.0869565" y="0.130435"/>
  </objectgroup>
 </tile>
 <tile id="208">
  <objectgroup draworder="index" id="3">
   <object id="2" template="Coliciones/Pared.tx" x="7.99987" y="0.169848" rotation="90.333"/>
  </objectgroup>
 </tile>
 <tile id="212">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Pared.tx" x="15.9394" y="-0.00681865" rotation="89.5773"/>
  </objectgroup>
 </tile>
 <tile id="224">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Pared.tx" x="7.8706" y="-0.0192331" rotation="89.4006"/>
  </objectgroup>
 </tile>
 <tile id="228">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Pared.tx" x="16.0529" y="0.227586" rotation="90.2647"/>
  </objectgroup>
 </tile>
 <tile id="234">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Esquinero.tx" x="8.0625" y="15.9375"/>
  </objectgroup>
 </tile>
 <tile id="235">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Esquinero.tx" gid="0" x="7.98438" y="15.9844" rotation="0">
    <polygon points="0,0 0,-5.9375 -2,-8 -7.9375,-7.9375 -7.875,-0.0625"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="236">
  <objectgroup draworder="index" id="3">
   <object id="3" template="Coliciones/Esquinero.tx" gid="0" x="8.01563" y="15.9844" rotation="0">
    <polygon points="0,0 0,-5.9375 2,-8 7.9375,-7.9375 7.875,-0.0625"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="237">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Esquinero.tx" x="-0.0173865" y="8.07248" rotation="90.0429"/>
  </objectgroup>
 </tile>
 <tile id="238">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Esquinero.tx" x="8.875" y="16.8125">
    <polygon points="-0.0625,-0.75 0,-5.9375 2,-8 7.1875,-7.9375 7.1875,-0.625"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="239">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Esquinero.tx" x="-1.00816" y="8.97934" rotation="89.6505">
    <polygon points="0.0173465,-1.02214 0,-5.9375 2,-8 7.05994,-7.97619 7.02481,-0.94548"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="240">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Esquina.tx" gid="0" x="15.875" y="16" rotation="0">
    <polygon points="-0.0390625,0.0585938 -0.0390625,-7.9375 -6.04297,-9.94141 -8.04297,-15.9258 -16.0352,-15.9336 -16.043,0.0585938"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="241">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Pared.tx" x="0.0625" y="8.125"/>
  </objectgroup>
 </tile>
 <tile id="242">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Pared.tx" x="0.125" y="8.1875"/>
  </objectgroup>
 </tile>
 <tile id="243">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Pared.tx" x="0" y="8.125"/>
  </objectgroup>
 </tile>
 <tile id="244">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Esquina.tx" gid="0" x="-0.0820625" y="15.9375" rotation="0">
    <polygon points="0.0390625,0.0585938 0.0390625,-7.9375 6.04297,-9.94141 8.04297,-15.9258 16.0352,-15.9336 16.043,0.0585938"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="250">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Esquinero.tx" gid="0" x="8.03125" y="-0.03125" rotation="0">
    <polygon points="0,0 0,5.9375 2,8 7.9375,7.9375 7.875,0.0625"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="251">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Esquinero.tx" gid="0" x="7.96875" y="0" rotation="0">
    <polygon points="0,0 0,5.9375 -2,8 -7.9375,7.9375 -7.875,0.0625"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="252">
  <objectgroup draworder="index" id="3">
   <object id="2" template="Coliciones/Esquinero.tx" gid="0" x="8.0625" y="0.125" rotation="0">
    <polygon points="0,0 0,5.9375 2,8 7.9375,7.9375 7.875,0.0625"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="253">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Esquinero.tx" x="7.95139" y="-0.0640217" rotation="179.752"/>
  </objectgroup>
 </tile>
 <tile id="254">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Esquinero.tx" x="16.9764" y="6.9844" rotation="269.777">
    <polygon points="-0.0509477,-0.961143 0,-5.9375 2,-8 7.03123,-7.93321 6.98007,-0.964427"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="255">
  <objectgroup draworder="index" id="2">
   <object id="1" template="Coliciones/Esquinero.tx" x="7.00565" y="-1.10605" rotation="179.862">
    <polygon points="0.0183004,-1.11324 0,-5.9375 2,-8 7.0199,-8.09205 7.01422,-1.10363"/>
   </object>
  </objectgroup>
 </tile>
</tileset>
